
// Multimedia Programming
// Assignment 1 / Static Image
// 313478 – Canberk Sahin – canberksahinn@gmail.com

function setup() {
  createCanvas(600, 600);
  noLoop(0);
}
function draw() 

{
  background(0);
  drawStars(); // Call the function to draw stars
  
  fill("#FFEC42");
  ellipse(300,300,500,500); // doomsday clock background

  stroke("#D40404F2"); // bloodsplash effect
  strokeWeight(8);
  line(111,140,111,300);
  line(113,140,113,400)
  strokeWeight(6);
  line(120,130,120,420);
  strokeWeight(10);
  line(140,115,140,280);
  strokeWeight(6);
  line(130,123,130,450);
  strokeWeight(15);
  line(135,118,135,400);
  strokeWeight(10);
  line(125,125,125,320);
  line(130,133,130,440);
  line(145,110,145,320);
  line(155,102,155,320);
  line(165,95,165,300);
  line(400,75,400,500);
  line(420,83,420,320);
  
  stroke(0); //vi
  strokeWeight(3); //vi
  line(288,500,308,500);
  line(290,500,295,520);
  line(295,520,300,500);
  line(305,500,305,520);
  line(289,520,308,520);
  line(518,290,532,290); //iii
  line(520,290,520,310);
  line(525,290,525,310);
  line(530,290,530,310);
  line(518,310,532,310);
  line(70,290,70,310); //ix
  line(75,290,85,310);
  line(75,310,85,290);
  line(68,290,86,290);
  line(68,310,86,310);
  line(285,70,295,90); //xii
  line(285,90,295,70);
  line(300,70,300,90);
  line(305,70,305,90);
  line(282,70,307,70);
  
  let triangleX = width / 2;
  let triangleY = height / 2;
  let triangleSize = 300; // size of the triangle

  
  stroke(0);
  strokeWeight(1);
  fill("#0D1E7D") //cape for winston
  rect(180,150,240,250);
  fill(255);
  rect(181,265,238,60);
  fill("#EA0730");
  rect(181,280,238,30);
  fill(255);
  triangle(180,400,180,385,195,400);
  strokeWeight(20);
  stroke(255);
  line(190,390,400,205);
  
  line(410,390,250,233);
  fill(255);
  strokeWeight(0);
  rect(410,390,10,10);

  strokeWeight(1); //body of winston
  fill(0);
  stroke("#FFFFFF");
  triangle(triangleX - triangleSize / 2, triangleY - triangleSize / 2, // Bottom vertex
           triangleX + triangleSize / 2, triangleY - triangleSize / 2, // Top left vertex
           triangleX, triangleY + triangleSize / 2); // Top right vertex

  fill(255);  //eyelashes
  line(234,219,217,202);
  line(261,205,257,183);
  line(338,205,345,183);
  line(362,217,380,201);
  
  fill(255); // eye
  ellipse(300, 250, 160, 100); 
  fill("#1D132F");

  stroke("#D82A1D");  //eye veins
  strokeWeight(3);
  ellipse(300, 250, 50, 100);
  line(220,253,230,253);
  line(230,253,250,245);
  line(230,230,250,245);
  line (230,270,240,270);
  line(240,270,250,245);
  line(250,245,263,253);
  line(250,245,270,235);
  line(250,245,260,235);
  line(250,280,270,260);
  line(250,280,250,260)
  line(250,260,244,260);
  line(260,235,260,220);
  line(260,220,267,223);
  line(263,253,268,245);
  line(260,270,270,275)

  line(width - 220, 253, width - 230, 253); //for symetry in eye veins
  line(width - 230, 253, width - 250, 245);
  line(width - 230, 230, width - 250, 245);
  line(width - 230, 270, width - 240, 270);
  line(width - 240, 270, width - 250, 245);
  line(width - 250, 245, width - 263, 253);
  line(width - 250, 245, width - 270, 235);
  line(width - 250, 245, width - 260, 235);
  line(width - 250, 280, width - 270, 260);
  line(width - 250, 280, width - 250, 260);
  line(width - 250, 260, width - 244, 260);
  line(width - 260, 235, width - 260, 220);
  line(width - 260, 220, width - 267, 223);
  line(width - 263, 253, width - 266, 245);
  line(width - 260, 270, width - 270, 275);
  


  stroke(0); //legs
  strokeWeight(10); 
  line(250, 350, 200, 450); // left leg
  ellipse(194,450,10,5);
  line(350, 350, 400, 450); // right leg
  ellipse(405,450,10,5);
  
  stroke(0); //arms
  strokeWeight(10);
  line(220, 270, 200, 350); //left arm
  ellipse(195,350,10,10);
  noStroke();
  fill("#763922"); //cigar
  ellipse(185,350,20,10);
  fill("#FF1807")
  ellipse(177,350,5,5);
  stroke(0);
  line(380, 270, 420, 300); //right arm

  noStroke(); //smoke for the cigar
  fill(200, 200, 200, 150);
  ellipse(180, 350, 10, 10);
  ellipse(175, 345, 8, 8);
  ellipse(190, 340, 12, 12);

  
  stroke(255); //hat
  strokeWeight(0.4);
  fill("#3F3E3E");
  ellipse(300,150,140,45);
  fill("#3F3E3E");
  noStroke();
  fill("#424040");
  stroke(1);
  rect(280,80,40,80,60);

  stroke(255); //bowtie
  fill("#DD4035");
  triangle(280, 320, 280, 340, 300, 330);
  triangle(320, 320, 320, 340, 300, 330);
  
  stroke(0); //staff
  fill(0);
  strokeWeight(6);
  line(430, 270, 400, 380); 

  fill("#DD4035")
  ellipse(430, 270, 30, 30);
  fill(240);
  noStroke();
  ellipse(428, 265, 10, 10);
  fill(255);
  ellipse(428, 265, 5, 5);
  
  stroke(0); //clock lines
  strokeWeight(1);
  line(300,10,300,60);
  line(300,590,300,540);
  line(10,300,60,300);
  line(590,300,540,300);

  
  strokeWeight(1);
   
  let rainbowColors = ['#FF0000', '#FF7F00', '#FFFF00', '#00FF00', '#0000FF', '#2E2B5F', '#8B00FF']; // rainbow laser
  let startX = 277;
  let endX = 600;
  let y = 250;

  for (let i = 0; i < rainbowColors.length; i++) {
    stroke(rainbowColors[i]);
    line(startX, y, endX, 0); 
    y += 2; 
  }

  noStroke();
  for (let i = 0; i < 20; i++) {
    let diameter = random(2, 5);
    let x = random(284,317);
    let y = random(216,278);
    let color = getRandomColor();
    
    fill(color);
    ellipse(x, y, diameter, diameter);
  }
}

function getRandomColor() {
  return color(random(255), random(255), random(255));


}
function drawStars() {
  for (let i = 0; i < 500; i++) {
    let x = random(width);
    let y = random(height);
    let diameter = random(1, 3); // random diameter for stars
    fill(255);
    ellipse(x, y, diameter, diameter);
  }
}

